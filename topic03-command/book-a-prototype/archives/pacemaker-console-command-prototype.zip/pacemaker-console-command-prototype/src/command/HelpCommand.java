package command;

import java.util.Set;

public class HelpCommand extends Command
{
  private Set<String> commandNames;

  public HelpCommand(Set<String> commandNames)
  {
    this.commandNames = commandNames;
  }

  public void doCommand(Object[] parameters)
  {
    System.out.println(commandNames.toString());
  }
}
