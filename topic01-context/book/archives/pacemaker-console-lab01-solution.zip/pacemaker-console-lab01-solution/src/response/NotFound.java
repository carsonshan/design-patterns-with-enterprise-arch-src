package response;

public class NotFound extends Response
{
  public NotFound(final String response)
  {
    super("not found\n");
  }
}
